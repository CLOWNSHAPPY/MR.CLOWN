# ACNv3
Tools Installer [ Army Cyber Network ] 100 Tool in 1
# Need Install
```
$pkg install git
$pkg install python2 -y
$pkg install figlet
$pip2 install lolcat
```
# Update
```
$cd ACNv3
$git pull
```
# Login
```
Username : Maulanarym
Password : subscribe
```
Tool ini Rata-rata berisikan Tools Terbaru</br>
Jika Ada yg Error Contact Me</br>
# Contact Me
Facebook : https://fb.me/Maulana.Rym</br>
Instagram : https://www.instagram.com/rizqymaulanarym/</br>

Enjoyyy...
